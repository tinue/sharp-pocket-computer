-------------------------------------------------- -----------------------
Name DSC61 : SC61860 DISASSEMBLER for Win32 (Rev 0.09)
Operating environment Win95/98/98SE/NT4/2000/XP/Vista/7/8/10
Creator Ao (QZE12045@nifty.com)
URL http://hd61700.yukimizake.net/SC61860/
-------------------------------------------------- -----------------------
■What is DSC61?
This is a disassembler for SC61860.
Operates in a Win32 cross environment (DOS prompt), with automatic symbol label generation function and
It has a conversion function for various file formats.
It's free software. Please use it as you like. Reproduction is also free.
(However, there is no guarantee)

■Features
(1) Most instructions supported by SC61860 can be disassembled.
  (I think there are some commands that are not supported...)
(2) It is possible to read formats with the following extensions.
   .PBF (PBF file)
   .BAS (BASIC DATA statement format)
   .HEX (PJ HEX format)
   .DMP (SC61 dump format. Equivalent to PJ HEX format)
   .TXT (ASCII format without address/checksum)
   .BIN (binary file)
   .BMP (Windows bitmap file--only monochrome (two-color) images supported)
   If you specify a file with an extension other than the above, it will be processed as a binary (*.bin) type.
(3) JR*/JP*/CAL/CALL instruction label analysis using N-pass method and LIDP instruction
   Data area analysis can be performed. (Executed with /S /D option specified)
   The label format output by analysis is as follows.
    START ---- Execution start address
    LBL＊ ---- JR/JP instruction usage label
    MDL＊ ---- CAL instruction usage label
    DAT＊ ---- LIDP instruction and data label using 16bit operands other than the above
    (* --- Address where the applicable label is defined)
    
    (4) For the areas found by the analysis using /S and /D above, please refer to the list of DB instruction formats.
   Automatically generated. With this function, executable files whose sources have been lost can also be saved.
   It is possible to repair almost automatically. (Sometimes it's not good)
(5) If there is a file named symbol.h in the same folder as DSC61,
   You can read symbol information from there.
   (Fixed system resources, etc. can be reflected in the disassembly result)
   The format is the same as the HD61 EQU instruction.
   #if~#else~#endif can be used as pseudo-instructions.
   If an error occurs while loading Symbol.h, the subsequent symbol information
   Stop loading and start disassembling.
(6)Comments for instruction execution analysis can be output at the same time as mnemonic output.
   (When /C option is specified)

(7) It is possible to convert the loaded file into various formats.
   The supported output formats are as follows.
   ・PBF format (please use for conversion from BAS/HEX)
   ・BAS format (please use for conversion from PBF/HEX)
   ・Binary format (BIN)
   ・Bitmap format (BMP)
   ・DB format (assembler DB instruction format)
   ・PJ HEX format (HEX format published in PJ magazine)
   ・INTEL HEX format (8 bit)

■Archive contents
Readme.txt --- This file
DSC61.exe ----- HD61700 disassembler executable file
Symbol.h ----- Symbol definition file sample

■How to start
Run the following at a Windows command prompt:

>DSC61 [Filename.Extension] [Option (/S /D /C /NC /B /DB /BMP /MONO /P /BAS /PJ /HEX /NTAB /IMG) Optional] [Enter]

When executed, the disassembly result will be output to a .lst file (or the conversion result to .pbf/.bas/.bin/.bmp/.hex/.hx).

■Input file format
The following formats are available:
If you specify a file of unknown type, it will be processed as a binary (*.bin) type.
   .PBF (PBF file)
   .BAS (BASIC DATA statement format)
   .HEX (PJ HEX format)
   .DMP (SC61 dump format. Equivalent to PJ HEX format)
   .TXT (ASCII format without address/checksum)
   .BIN (binary file)
   .BMP (Windows bitmap file--only monochrome (two-color) images supported)

Each file format is determined by its extension name, so if the name is incorrect, it will not be read correctly.
The file formats and extension names are as follows.
(1) *.PBF --- PBF format. HD61/BinToPbf output format.
  /ADR specification is not necessary as it has all address information.

(2) *.BAS --- BASIC DATA statement format (2 digit hexadecimal with checksum)
  BASIC DATA statement format.
     1000 DATA D162389377AB02D6,F8
     1010 DATA 40D512D600D402D6,A9
                   :
  Since it does not have address information, use the /ADR option in the order of [start address] and [execution address].
  You need to specify the address.
   Example) DSC61 sample.bas /s /adr 0xD000 0xD018

(3) *.HEX / *.DMP --- PJ HEX format (address/hexadecimal 2 digits with checksum)
  PJ HEX format refers to the HEX format published in PJ magazines such as the following.
  You can use a colon [:], comma [,], or space to separate addresses/data/checksums.
     2A65 6200C0D6001C2E77,B9
     2A6D 7C2AD16200FFD600,AE
                :
  [Execution address] can be specified with the /ADR option. (/ADR can also be omitted)
   Example) DSC61 sample.hex /s /adr 0xC018

(4) *.TXT --- ASCII format (no address/checksum)
  TXT is a file whose data content is in ASCII format as shown below.
  Only data, no address/checksum information.
     40D512D600D402D6
     20E502D8D6409513
            :
     D600E602D620F702
   You need to specify the [start address] and [execution address] with the /ADR option.
   Example) DSC61 sample.txt /s /adr 0xD000 0xD018

(5) *.BIN --- Binary format
  The above (1) to (4) are in ASCII format, but the binary format is the memory data itself.
  Since it has only data and no address/checksum information, use the /ADR option.
  You need to specify the addresses in the order of [start address] and [execution address].
   Example) DSC61 sample.bin /s /d /adr 0xC000 0xC018

(6) *.BMP --- Bitmap format
   Windows bitmap image format.
   Images created on a computer can be converted to PBF format and used on a Pocket Computer.
   Only monochrome (two-color) format images can be loaded.
   There is no particular limit to the image size that can be loaded, but considering the use with CASIO Pocket Computer,
   It would be most convenient to operate with either 192x32 or 192x64.
   For the time being, the OS2 format is also supported, but I haven't tested it much, so I would prefer to use the Windows format.
   Please use BMP images. (Confirmed only with OS2 format BMP created with Photoshop Elements)
   It is possible to specify [start address] and [execution address] with the /ADR option, but
   Omitting it will not result in an error. (If address is omitted, it will be stored starting from address 0)

■Option explanation
(1) Disassembly options
/S ---- If an execution start address is specified, start from that address.
         Starts instruction analysis.
/D ---- Data area for LDW/PRE command when the above /S option is specified
         Perform analysis.
         (/D cannot be used alone. Must be used together with /S)
/C ---- Outputs instruction execution comments.
         Please use it when analyzing motion.
/NC ---- Does not output addresses and codes during disassembly.
         Outputs only the source. (For source repair only)
/AC ---- Disassembles under the same conditions as /NC, but outputs "address + code + character" as a comment.
/NTAB -- Do not use TAB for list output. Default is TAB=8.
/IMG --- The area specified in binary by the SA pseudo-instruction is converted into a monochrome bitmap in GPRINT format.
         Output to file. The file name is "label name.bmp" of the target address, or
         It becomes "Img address.bmp".

The analysis algorithm is quite arbitrary, so it can accurately define the code area and data area.
It doesn't necessarily mean that they can be separated. There are many possibilities that things will not go well.
In particular, the /D option is not recommended for code that includes a mixture of instruction codes and data areas, such as processing within the BIOS.
It's better to think that you can't use it at all.

(2)Data conversion options
  /P ---- Outputs the input file in PBF format.
  /BAS --- Outputs the input file in BAS (BASIC DATA statement) format.
  /DB ---- Outputs the input file in DB instruction format.
           Can be used in conjunction with the /NC option.
  /B ---- Outputs the input file in binary format.
           The extension of the output file will be .bin.
  /BMP (start address) ---- Input file in bitmap format (192×32/192×64)
           Output. The extension of the output file will be .bmp.
           /bmp [start address] creates a bitmap from that physical address.
           The start address can be specified as a decimal or hexadecimal number (add 0x at the beginning).
           Please use it to take screenshots of the screen.
      (Example)>DSC61 Graphic.pbf /bmp 0xC210
  /MONO (start address) ---- Input file in bitmap format (192×32/192×64)
           Output. The extension of the output file will be .bmp.
           It works almost the same as /BMP, but the output image looks like an LCD screen.
           (Sorry, the palette colors are quite appropriate.)
  /PJ ---- Outputs the input file in PJ HEX format (extension .hex/.hx). *
  /HEX --- Outputs the input file in INTEL HEX format (extension .hex/.hx). *
           *If the input file extension is .hex, the output file extension will be .hx.
If you select these options for data conversion, the process will end without disassembling.
Also, if multiple data conversion options are specified, only the last option specified will be valid.

(3) Addressing options
  /ADR (Address 1) (Address 2) ---- When reading BAS/HEX/BIN/TXT format files,
          Specify the disassembly start address/execution start address.
          - The execution start address can be omitted.
          - When the input is a PJ HEX file, only the execution start address can be specified.
          - Ignored when the input is a PBF file.
  (Example 1) For the binary file (source.bin), start address $2000,
      Specify the execution start address $2010.
   >DSC61 source.bin /adr 0x2000 0x2010 [Enter]
  (Example 2) Specify the execution start address $2010 for the PJ HEX file (source.hex).
   >DSC61 source.hex /adr 0x2010 [Enter]

■About using Symbol.h
If there is a file named symbol.h in the same folder as the source file, symbol information will be extracted from there.
It can be loaded. (Fixed system resources, etc. can be reflected in the disassembly result)
If an error occurs while reading Symbol.h, the subsequent reading of symbol information is canceled and
Start disassembling.

The available formats are as follows.
(1)EQU
  Format [LABEL(:)] EQU [number] (or LABEL/formula)
  Function: Gives the numerical value of the operand to the declared label. Label declaration cannot be omitted.
        Labels and expressions can be used as operand values, but the values must be determined at the time of use.
        Note that the colon ':' placed immediately after the label can be omitted for the EQU command only.

(2)IF～ELSE～ENDIF
  Format IF (!)[expression]
        << Description 1 >>
       (ELSE
        << Description 2 >>)*
       ENDIF
       *(ELSE~<<Description 2>>) can be omitted.
  Function If the value of operand 1 of the if instruction is true (= other than 0), description 1 is enabled (from else to endif).
        (invalidate description 2). You can also use the operator ![reverse evaluation value] in expressions.
        (The precedence of the ! operator is between unary operators and parentheses.)
        A label can also be specified in the expression, but the value must be determined at the time of use.
        Nesting of IF ~ ELSE ~ ENDIF is also possible. (up to level 255)

(3)INCLUDE
  Format INCLUDE(file name)
  Function: Includes the file written within the parentheses of operand 1 during assembly.
        When the assembler finds this statement, it stops assembling the source file and starts INCLUDE.
        Assembles the specified files. After the specified file is assembled, the original
        Resume assembling the source file.
        INCLUDE nesting is possible up to 256 levels. of an already opened INCLUDE file
        Recursive calls will result in an "Invalid Include File Name" error.
​(4)SA
  Format ([LABEL:]) SA(Type W/S/B) [Numeric value 1] (,[Numeric value 2]) (,[Numeric value 3]) (;Comment (character string))
  Function Registers the range of operand numbers 1 to 2 as a data area to the disassembler.
        If you have [Number 3], you can specify a divisor such as area width. For example, a width of 192 bytes like LEDTP
        If you have a work area, register it in Symbol.h as shown in the example below.
        In the disassembly list output, it is possible to write something like [buffer name + divisor *Y+X].
  (example)
          LEDTP: SA $6343,$6642,192 ;LCD display dot buffer

        The type is described as SA (none), SAW (output in DW), SAS (character string output), and SAB (binary = binary output).
        You can specify the lst output of the assembly result for each type, so you can output the work found after analysis.
        Specifying SA is useful for organizing the work area.
       
        Labels and expressions can be used for each operand numeric value, but the value must be determined at the time of use.
        Also, the label declaration can be omitted and only the SA pseudo-instruction can be registered, but in that case, the comment
        It is not reflected in the disassembly result. (Because the comment display is linked to the label declaration)
       
        When the /img option is specified, the area defined in SAB (binary = binary output) is converted into GPRINT format.
        Output as an image file.
        The output is in monochrome (two-color) bitmap format, and if a label is specified, the file name is "label name.BMP".
        If no label is specified, it will be "img+address.BMP".
        It is converted into a bitmap with 8 bits vertically, but if a region width is specified, the image is wrapped with that width.
        Output.
■ References
When developing DSC61, I referred to the contents of the following sites.
1. "SC61860 mnemonic table"
    (http://www.d1.dion.ne.jp/~steduka/pc12_database.htm)
2. “CASE instruction operation specifications”
    (https://www.oit.ac.jp/rd/labs/kobayashi-lab/~yagshi/old_web/misc/pocketcom/yasm.html)

■ History
Rev: 0.01 2006.10.13 First version.
Rev: 0.02 2006.10.16 Compatible with CASE1/CASE2. Corrected BMP input/output to SC format.
                         Improved command execution comment output (/C option).
Rev: 0.03 2006.11.07 Comment correction. Fixed CASE2 decoding. *.DMP added.
                         Fixed invalid code check.
Rev: 0.04 2006.12.24 Corrected to change the file name of unknown type to *.bin type.
Rev: 0.04 2009.02.12 Recompiled. Uncompress UPX (because Virus Buster malfunctions)
                         The version number remains unchanged.
Rev: 0.05 2009.11.20 Corrected IYS/IXS comment output (By YANAGIDA)
Rev: 0.06 2021.07.11 Fixed PBF format output. (Fixed the comma at the end of the file)
                         Unified "unsigned long" and "unsigned short" specifications to "unsigned int".
                         I used it for an old compiler (DOS), but with a recent Linux compiler.
                         I corrected it because the compatibility was not good.
                         Abolished EOF output (Win32 version).
Rev: 0.07 2021.08.25 Made CASE1/CASE2 output compliant with SC61.
Rev: 0.08 2022.05.01 Supports SA pseudo instructions. Equipped with label comment output and area analysis functions.
                         Corrected Checksum when specifying Intel HEX output (/hex).
                         /img option added. The area specified in binary by the SA pseudo-instruction is
                         Output to GPRINT format bitmap.
Rev: 0.08a 2022.05.01 /img option correction. The version numbers are the same.
Rev: 0.09 2023.06.18 Fixed issue where dump data output is corrupted when SAS is specified
                         Supports include directive when reading symbol.h.
                         /AC option specification added. Same conditions as /NC and "address + code + character"
                         Output as a comment.
                         If a label definition error occurs while reading Symbol.h, a warning will be displayed and processing will continue.
                         Added a warning display when the same value label is defined as EQU.
​
