die Sourcen lassen sich mit wenig Aufwand auch unter Linux kompilieren.
